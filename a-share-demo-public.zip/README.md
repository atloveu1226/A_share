# A股研究终端 Demo

这是一个匿名公开演示版 A 股研究终端，用于展示自选扫描、K 线、T 点区间、持仓压力和风险纪律。

`docs/` 是 GitHub Pages 静态站点根目录，不依赖后端、AKShare、SQLite、同花顺或任何券商接口。里面只包含 DEMO 样本数据，不包含真实股票、成本、仓位或账号信息。

## GitHub Pages

推荐做法：

1. 在 GitHub 创建一个新仓库。
2. 把本项目推到仓库的 `main` 分支。
3. 在仓库 `Settings -> Pages` 中选择 `GitHub Actions`。
4. 等待 `Deploy GitHub Pages` workflow 运行完成。

也可以用分支目录方式：

1. 在 `Settings -> Pages` 里选择 `Deploy from a branch`。
2. Branch 选 `main`，目录选 `/docs`。

## 本地预览

直接打开 `docs/index.html` 即可预览公开版页面。

## 项目结构

- `docs/`: GitHub Pages 公开静态 Demo。
- `app/`: Sites/Vinext 版本源码。
- `.github/workflows/pages.yml`: GitHub Pages 自动部署 workflow。
